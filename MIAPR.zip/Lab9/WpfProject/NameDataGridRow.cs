﻿using System;

namespace WpfProject
{
    public class NameDataGridRow
    {
        public NameDataGridRow(string name)
        {
            Name = name;
        }

        public String Name { get; set; }
    }
}